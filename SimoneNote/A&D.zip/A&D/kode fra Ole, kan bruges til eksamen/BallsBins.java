

public class BallsBins
{
    

static int moreThanOneBallPerBin(int bins[], int noOfBins)
{
    int balls;
    balls = noOfBins;//(int)Math.sqrt(noOfBins);
     
    for (int i = 0; i < noOfBins; i++)
        bins[i] = 0;

    for (int i = 0; i < balls; i++)
    {
        int ix = (int) (Math.random() * noOfBins);
        bins[ix]++;
    }

    int moreThanOne = 0;
    for (int i = 0; i < noOfBins; i++)
        if (bins[i] > 1)
            moreThanOne++;
    return moreThanOne;
}

static int maxBallsPerBin(int bins[], int noOfBins)
{
    int balls;
    balls = noOfBins;
     
    for (int i = 0; i < noOfBins; i++)
        bins[i] = 0;

    for (int i = 0; i < balls; i++)
    {
        int ix = (int) (Math.random() * noOfBins);
        bins[ix]++;
    }

    int max = 0;
    for (int i = 0; i < noOfBins; i++)
        if (bins[i] > max)
            max = bins[i];
    return max;
}

static int ballsBinsPOTC(int bins[], int noOfBins)
{
    int balls;
    balls = noOfBins;
    
    for (int i = 0; i < noOfBins; i++)
        bins[i] = 0;

    for (int i = 0; i < balls; i++)
    {
        int ix1 = (int) (Math.random() * noOfBins);
        int ix2 = (int) (Math.random() * noOfBins);
        if (bins[ix1] > bins[ix2])
            bins[ix2]++;
        else
            bins[ix1]++;
    }

    int moreThanOne = 0;
    for (int i = 0; i < noOfBins; i++)
        if (bins[i] > 1)
        moreThanOne++;
    return moreThanOne;
}

static int maxBallsPerBinsPOTC(int bins[], int noOfBins)
{
    int balls;
    balls = noOfBins;//(int)Math.sqrt(noOfBins);
    
    for (int i = 0; i < noOfBins; i++)
        bins[i] = 0;

    for (int i = 0; i < balls; i++)
    {
        int ix1 = (int) (Math.random() * noOfBins);
        int ix2 = (int) (Math.random() * noOfBins);
        if (bins[ix1] > bins[ix2])
            bins[ix2]++;
        else
            bins[ix1]++;
    }

    int max = 0;
    for (int i = 0; i < noOfBins; i++)
        if (bins[i] > max)
        max = bins[i];
    return max;
}
static String mSquareNLessThanHalf(int size)
{
    int[] bins = new int[size*size]; int yes = 0; int no = 0;
    for (int j = 0; j < 100; j++)
    {
        boolean found = false;
        for (int m = 0; m < size*size; m++)
            bins[m] = 0;
        for (int i = 0; i < size; i++)
        {
            int ix = (int) (Math.random() * size*size);
            bins[ix]++;
        }
        for (int i = 0; i < size*size; i++)
        {
            if (bins[i] > 1)
            {
                yes++;
                found = true;
                break;
            }
        }
        if (!found) no++;
    }
    return "Yes: "+yes+" No: "+no;

}
static int myHash(String key, int tableSize)
{
    int hashVal = 0;
    for (int i = 0; i < key.length(); i++)
    {
        char ch = key.charAt(i);
        hashVal = 37 * hashVal + ch;
    }
    return Math.abs(hashVal % tableSize);
}

static void polynominalProbing()
{
    int arr[] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    String keys[] = { "olsen", "svend","poulsen", "hubert","stubberup","kalundborg","oerlund","byrum","dangmand","yeerday","babaoriley" };
    for (int i = 0; i < 11; i++)
    {
        int ix = myHash(keys[i], 19);
        int org = ix;
        for (int j = 1; arr[ix] != 0; j++)
        {
            ix = (org + j*j*j*j*j) % 19;
            System.out.println(i+1 +" "+ ix);
        }
        arr[ix] = i+1;
    }
    System.out.println("PB completed ");
    for (int i = 0; i < 19; i++)
        System.out.print(arr[i] + " ");
    System.out.print('\n');
}

public static void main(String [] args)
{
    System.out.println("This is balls and bins.");

    int noOfBins = 32767;
   
    int[] bins;
    bins = new int[noOfBins];
    
    System.out.println( noOfBins + " Normal     " + moreThanOneBallPerBin(bins, noOfBins));
    System.out.println( noOfBins + " POTC       " + ballsBinsPOTC(bins, noOfBins));
    System.out.println( noOfBins + " Normal max " + maxBallsPerBin(bins, noOfBins));
    System.out.println( noOfBins + " POTC max   " + maxBallsPerBinsPOTC(bins, noOfBins));
    System.out.println(mSquareNLessThanHalf(11));
    //polynominalProbing();
    
}
}
