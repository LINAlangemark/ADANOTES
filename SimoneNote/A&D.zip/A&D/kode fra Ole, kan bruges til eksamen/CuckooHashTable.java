/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ada2020;

/**
 *
 * @author od
 */
public class CuckooHashTable 
{
    private static final int LOGICAL_SIZE = 13;
    private String [][] contents;
    private int currentSize;
    
    public CuckooHashTable()
    {
        contents = new String [LOGICAL_SIZE] [2];
        currentSize = 0;
    }
    
    boolean find(String value)
    {
        String res = "";
        res = contents[value.hashCode()% LOGICAL_SIZE][0];
        if (res.compareTo(value)== 0)
            return true;
        res = contents[(value.hashCode() * 2) % LOGICAL_SIZE][1];
        if (res == null)
            return false;
        return true;
    }
    
    public void makeEmpty()
    {
        for (int i= 0; i < contents.length; i++)
            for (int j = 0; j < contents[0].length; j++)
                contents [i] [j] = null;
    }
    
    public int hashCode(String value, int which)
    {
        return (value.hashCode() * (which+1)) % LOGICAL_SIZE;
    }
    
    public String fetchIx(int row,int col)
    {
        return contents[row][col];
    }
    
    public void add(String value)
    {
        System.out.printf("Entering add() with value = %s\n", value);
        int desiredCol = 0;
        int desiredRow = hashCode(value, desiredCol);
        
        while(true)
        {
            System.out.printf("contents[%d][%d] = ", desiredRow, desiredCol);
            System.out.println(contents[desiredRow] [desiredCol]);
            
            if (contents[desiredRow][desiredCol] == null)
            {
                contents[desiredRow][desiredCol] = value;
                break;
            }
            else
            {
                String victim = contents[desiredRow][desiredCol];
                contents[desiredRow][desiredCol] = value;
                
                desiredCol = (desiredCol + 1) % contents[0].length;
                desiredRow = hashCode(victim, desiredCol);
                contents[desiredRow][desiredCol] = victim;
                
                System.out.printf("Need to replace a victim: %s\n", victim);
                System.out.printf("  new row/col = [%d][%d]\n" , desiredRow, desiredCol);
                break;
            }
        }
    }
    
    
    
}
