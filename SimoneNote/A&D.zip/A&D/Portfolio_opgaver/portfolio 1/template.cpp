#include <iostream>
#include <vector>
#include <string>


//Exercise 1
int exercise1(int N)
{
    /*
    YOUR CODE
    */
    return 0;
}

//Exercise 3
bool additive(std::string s)
{
    /*
    YOUR CODE
    */
    return 0;
}

//Exercise 4
std::vector<int> exercise4(std::vector<int> array)//Or use array[] if u want
{
    /*
    YOUR CODE
    */
    return { 0 };
};

//Exercise 6
int sumDivisibleBy3(int N)
{
    /*
    YOUR CODE
    */
    return 0;
}

//Exercise 7
std::vector<int> exercise7(int Z)
{
    /*
    YOUR CODE
    */
    return { 0 , 0 }; //{X, Y}
};


//Exercise 10
long logTo(int N)
{
    /*
    YOUR CODE
    */
    return 0;
};

//Exercise 11
int exercise11(std::vector<int> array, int size) //Or you can use array[]
{
    /*
    YOUR CODE
    */
    return 0;
};


int main()
{
    printf("------------------------- Exercise 1 -------------------------\n\n");
    printf("---- Test 1 ----\n\n");
    int some_input1 = 0;//Fill in your input

    printf("Input is: %2d\n\n", some_input1); //Print the input
    int some_result1 = exercise1(some_input1);
    printf("Result is:  %2d\n\n", some_result1); //Print the result

    printf("If you have more tests print the input and output of them as well\n\n");
    printf("---- Test 2 ----\n\n");
    int some_input12 = 0;
    printf("Input is: %2d\n\n", some_input12); //Print the input
    int some_result12 = exercise1(some_input12);
    printf("Result is:  %2d\n\n", some_result12); //Print the result

    printf("------------------------- Exercise 3 -------------------------\n\n");

    printf("---- Test 1 ----\n\n");
    std::string some_input2 = "A string";
    printf("Input is: %s\n\n", some_input2.c_str()); //Print the input
    bool some_result2 = additive(some_input2);
    printf("Result is:  %2d\n\n", some_result2); //Print the result

    printf("------------------------- Exercise 4 -------------------------\n\n");
    printf("And so on .... \n");
    //And so on


    //This is the terminal output

    //------------------------- Exercise 1 -------------------------

    //    ----Test 1 ----

    //    Input is : 0

    //    Result is : 0

    //    If you have more tests print the input and output of them as well

    //    ----Test 2 ----

    //    Input is : 0

    //    Result is : 0

    //    ------------------------- Exercise 3 -------------------------

    //    ----Test 1 ----

    //    Input is : A string

    //    Result is : 0

    //    ------------------------- Exercise 4 -------------------------

    //    And so on ....

    return 0;
}

