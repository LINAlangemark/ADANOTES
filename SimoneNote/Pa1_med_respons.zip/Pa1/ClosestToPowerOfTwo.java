import java.util.Arrays;

public class ClosestToPowerOfTwo {
    // Implementering af metode til at finde den nærmeste potens af 2
    public static int nearestPowerOfTwo(int x) {
        int power = 0;
        while (Math.pow(2, power) < x) { // Finder den potens af 2, der er mindre end x
            power++;
        }
        return (int) Math.pow(2, power - 1); // Returnerer den potens af 2, der er nærmest x
    }

    // Implementering af metode til at finde de tre tal i nums, hvis sum er tættest på en potens af 2
    public static int[] findClosest(int[] nums) {
        int n = nums.length;
        int[] result = new int[4];
        int minDiff = Integer.MAX_VALUE;

        // Tre for-løkker til at finde alle kombinationer af tre tal i nums
        // Der beregnes summen af de tre tal og den nærmeste potens af 2
        // Hvis differencen mellem summen og den nærmeste potens af 2 er mindre end minDiff, opdateres minDiff og result
        for (int i = 0; i < n - 2; i++) {
            for (int j = i + 1; j < n - 1; j++) {
                for (int k = j + 1; k < n; k++) {
                    int sum = nums[i] + nums[j] + nums[k];
                    int nearestPower = nearestPowerOfTwo(sum);
                    int diff = Math.abs(sum - nearestPower);

                    // Opdaterer minDiff og result, hvis diff er mindre end minDiff
                    if (diff < minDiff) {
                        minDiff = diff;
                        result[0] = nums[i];
                        result[1] = nums[j];
                        result[2] = nums[k];
                        result[3] = nearestPower;
                    }
                }
            }
        }
        return result;
    }

    public static void main(String[] args) {
        int[] nums = {23, 56, 22, 11, 65, 89, 3, 44, 87, 910, 45, 35, 98};
        int[] result = findClosest(nums);
        System.out.println(Arrays.toString(result));
    }
}